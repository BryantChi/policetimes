<div class="table-responsive p-3">
    <table class="table" id="advertisementInfos-table">
        <thead>
            <tr>
                <th>名稱</th>
                <th>圖片</th>
                <th>連結</th>
                {{-- <th>狀態</th> --}}
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($advertisementInfos as $advertisementInfo)
                <tr>
                    <td>{{ $advertisementInfo->advertisement_name }}</td>
                    <td>{{ $advertisementInfo->advertisement_img }}</td>
                    <td>{{ $advertisementInfo->advertisement_link }}</td>
                    {{-- <td>{{ $advertisementInfo->advertisement_status }}</td> --}}
                    <td width="120">
                        {!! Form::open(['route' => ['admin.advertisementInfos.destroy', $advertisementInfo->id], 'method' => 'delete']) !!}
                        <div class='btn-group'>
                            {{-- <a href="{{ route('admin.advertisementInfos.show', [$advertisementInfo->id]) }}"
                                class='btn btn-default btn-xs'>
                                <i class="far fa-eye"></i>
                            </a> --}}
                            <a href="{{ route('admin.advertisementInfos.edit', [$advertisementInfo->id]) }}"
                                class='btn btn-default btn-xs'>
                                <i class="far fa-edit"></i>
                            </a>
                            {!! Form::button('<i class="far fa-trash-alt"></i>', [
                                'type' => 'button',
                                'class' => 'btn btn-danger btn-xs',
                                'onclick' => "return check(this)",
                            ]) !!}
                        </div>
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
