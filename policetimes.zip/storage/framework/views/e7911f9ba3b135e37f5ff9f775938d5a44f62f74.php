<div class="<?php echo e($class); ?>" id="<?php echo e($id); ?>">

    <div class="d-block">
      <!-- <div class="text-center">
				<img src="images/fimgs/icon128.png" class="img-fluid" alt="">
			</div> -->
      <!-- <div class="loading loading06">
				<span data-text="F">F</span>
				<span data-text="M">M</span>
				<span data-text="D">D</span>
			</div> -->
      <div class="loading loading06">
        <span data-text="L">L</span>
        <span data-text="O">O</span>
        <span data-text="A">A</span>
        <span data-text="D">D</span>
        <span data-text="I">I</span>
        <span data-text="N">N</span>
        <span data-text="G">G</span>
        <!-- <span data-text="載">載</span>
        <span data-text="入">入</span>
        <span data-text="中">中</span> -->
        <span data-text=".">.</span>
        <span data-text=".">.</span>
        <span data-text=".">.</span>
      </div>
    </div>
  </div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/policetimes/resources/views/components/loading.blade.php ENDPATH**/ ?>