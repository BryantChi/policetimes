<?php $__env->startSection('content'); ?>
    <div class="main position-relative" id="main" style="overflow: hidden;">

        <!-- Local News Section -->
        <div class="container-xxl px-0 pt-lg-auto pt-5 position-relative">
            <div class="container-lg-fluid px-lg-5 px-3 mx-md-5">
                <div class="row news mx-md-5" id="news">
                    <div class="col-lg-9">
                        <div class="local-news-title mt-1 mr-5">
                            <h3>地方要聞</h3>
                            <p class="mb-0">Local News</p>
                        </div>
                        <div class="line-red"></div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <div class="local-news-content text-center">
                                    <picture>
                                        <source srcset="<?php echo e(asset('assets/images/04/04ban_480.jpg')); ?>" media="(max-width: 768px)">
                                        <source srcset="<?php echo e(asset('assets/images/04/04ban_1024.jpg')); ?>" media="(max-width: 1024px)">
                                        <source srcset="<?php echo e(asset('assets/images/04/04ban_1280.jpg')); ?>" media="(max-width: 1280px)">
                                        <img src="<?php echo e(asset('assets/images/04/04ban_1280.jpg')); ?>" alt="" class="img-fluid content-img">
                                    </picture>
                                </div>
                            </div>

                        </div>

                        <div class="row mt-3">
                            <div class="col-12">
                                <div class="local-news-body">
                                    <?php $__currentLoopData = $localNewsInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localNews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="local-news-item d-flex justify-content-between align-items-center">
                                        <a href="<?php echo e(route('local-news.detail', [$localNews->id])); ?>">
                                            <div class="local-news-item-title d-flex align-items-center">
                                                <span class="text-danger">•</span>
                                                <p class="mb-0 single-ellipsis"><?php echo e($localNews->title); ?></p>
                                            </div>
                                        </a>
                                        <div class="local-news-item-date"><?php echo e($localNews->release_date); ?></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>

                        </div>

                        <div class="overflow-auto mb-3">
                            <?php echo e($localNewsInfos->onEachSide(3)->links('layouts_main.custom-pagination')); ?>

                        </div>

                    </div>
                    <div class="col-lg-3">
                        <?php $__currentLoopData = $adInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($ad->advertisement_link); ?>" target="_blank">
                                <img src="<?php echo e(env('APP_URL') . '/uploads/' . $ad->advertisement_image); ?>"
                                    class="img-fluid local-news-imgs2" alt="">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_main.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bryantchi/Documents/MWStudio Code/policetimes/resources/views/local-news.blade.php ENDPATH**/ ?>