<!-- Hero News -->
<div class="block-quick-info-2">
    <div class="container px-lg-5 px-2">
        <div class="block-quick-info-2-inner p-0 hero-news mx-lg-5 mx-3">
            <div class="news-mask"></div>
            <div class="row">
                <div class="col-lg hero-news-list">
                    <div class="row justify-content-center">
                        <div class="col-lg-auto d-lg-block d-flex justify-content-between align-self-center">
                            <div>
                                <h5 class="mb-0">最新警政新聞</h5>
                                <p class="mb-2">News</p>
                            </div>
                            <a href="<?php echo e(route('news')); ?>">
                                <div class="btn-outline-more d-flex justify-content-center align-items-center">
                                    <span class="mr-2">MORE</span>
                                    <img src="<?php echo e(asset('assets/images/00-hp/m_arrow.png')); ?>" class="img-fluid" width="20px" alt="">
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-auto">
                            <div class="hero-news-line"></div>
                        </div>
                        <div class="col-lg mt-3">
                            <ul class="pl-1 align-items-center list-unstyled hero-news-list-content">
                                <?php $__currentLoopData = $heroNewsInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="w-100 d-flex justify-content-between">
                                    <a href="news-inner.html">
                                        <div class="d-flex align-items-center">
                                            <span class="text-danger">•</span>
                                            <p class="mb-0 multiline-ellipsis-2"><?php echo e($news->title); ?></p>
                                        </div>
                                    </a>
                                    <span class="ml-3 " style="white-space:nowrap;"><?php echo e($news->release_date); ?></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                    </div>
                </div>

                <div class="col-lg-auto hero-news-slogn d-flex justify-content-center align-items-center">
                    <div>
                        <h5 class="text-with-line">警大時報</h5>
                        <h4>報導員警好人好事，<br class="d-block d-lg-none">替警界發聲</h4>
                        <h5>成為警察最有力的後盾。</h5>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/policetimes/resources/views/layouts_main/hero-news.blade.php ENDPATH**/ ?>