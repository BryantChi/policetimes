<div class="table-responsive p-3">
    <table class="table" id="localNewsInfos-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>標題</th>
                <th>發布日期</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $localNewsInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localNewsInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($localNewsInfo->id); ?></td>
                    <td><?php echo e($localNewsInfo->title); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($localNewsInfo->release_date)->format('Y-m-d')); ?></td>
                    <td width="120">
                        <?php echo Form::open(['route' => ['admin.localNewsInfos.destroy', $localNewsInfo->id], 'method' => 'delete']); ?>

                        <div class='btn-group'>
                            
                            <a href="<?php echo e(route('admin.localNewsInfos.edit', [$localNewsInfo->id])); ?>"
                                class='btn btn-default btn-xs'>
                                <i class="far fa-edit"></i>
                            </a>
                            <?php echo Form::button('<i class="far fa-trash-alt"></i>', [
                                'type' => 'button',
                                'class' => 'btn btn-danger btn-xs',
                                'onclick' => "return check(this)",
                            ]); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/policetimes/resources/views/admin/local_news_infos/table.blade.php ENDPATH**/ ?>