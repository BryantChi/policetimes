<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH /Users/bryantchi/Documents/MWStudio Code/policetimes/resources/views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>