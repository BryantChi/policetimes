<?php

namespace App\Http\Controllers;

use App\Models\Admin\AdvertisementInfo;
use App\Models\Admin\LocalNewsInfo;
use App\Models\Admin\NewsInfo;
use App\Repositories\Admin\SeoSettingRepository;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    //
    public function index(){
        $seoInfo = SeoSettingRepository::getInfo();
        $heroNewsInfos = NewsInfo::orderBy('created_at', 'desc')->limit(3)->get();
        $localNewsInfos = LocalNewsInfo::orderBy('created_at', 'desc')->limit(7)->get();
        $adInfos = AdvertisementInfo::orderBy('created_at', 'desc')->limit(10)->get();
        return view('index')
            ->with('seoInfo', $seoInfo)
            ->with('heroNewsInfos', $heroNewsInfos)
            ->with('localNewsInfos', $localNewsInfos)
            ->with('adInfos', $adInfos);
    }
}
